var modal = document.getElementById('id01');
window.onclick = function (event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
var modal = document.getElementById('id02');
window.onclick = function (event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
$(function () {
    $('#mi-slider').catslider();
});