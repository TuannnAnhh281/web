<!--Footer-part-->
<div class="row-fluid">
    <div id="footer" class="span12"> 2018 &copy; Design by PHP.Phạm Lê Minh Phú - 16211TT2360 - TDC - Lập trình web 1</div>
</div>