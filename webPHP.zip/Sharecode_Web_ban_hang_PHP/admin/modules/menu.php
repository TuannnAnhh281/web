<!--sidebar-menu-->
<div id="sidebar"> <a href="#" class="visible-desktop">
        <i class="icon icon-bar-chart icon-2x" style="padding: 10px;">
        </i>
    </a>
    <ul>
        <li >
            <a href="index.php">
                <i class="icon icon-2x icon-dashboard"></i>
                <span><strong>Dashboard</strong></span>
            </a> 
        </li>
        <li>
            <a href="index.php?quanly=loaisp&ac=lietke">
                <i class="icon icon-2x icon-table"></i>
                <span>Quản lý Loại sản phẩm</span>
            </a> 
        </li>
        <li>
            <a href="index.php?quanly=hieusp&ac=lietke">
                <i class="icon icon-2x icon-table"></i>
                <span>Quản lý Nhà sản xuất</span>
            </a>
        </li>
        <li>
            <a href="index.php?quanly=sanpham&ac=lietke">
                <i class="icon icon-2x icon-table"></i> 
                <span>Quản lý Sản phẩm</span>
            </a>
        </li>
        <li>
            <a href="index.php?quanly=tintuc&ac=lietke">
                <i class="icon icon-2x icon-table"></i>
                <span>Quản lý Tin tức</span>
            </a>
        </li>
        <li>
            <a href="index.php?quanly=taikhoan&ac=lietke">
                <i class="icon icon-2x icon-table"></i>
                <span>Quản lý Tài khoản</span>
            </a>
        </li>
        <li>
            <a href="index.php?quanly=gallery&ac=lietke">
                <i class="icon icon-2x icon-table"></i>
                <span>Quản lý Gallery</span>
            </a>
        </li>
        <li>
            <a href="index.php?quanly=hoadon&ac=lietke">
                <i class="icon icon-2x icon-table"></i>
                <span>Quản lý Hóa đơn<span>
            </a>
        </li>
        <li>
            <a href="../admin/index.php?quanly=admin&ac=xuly">
                <i class="icon icon-user icon-2x">
                </i> Tài khoản Cá nhân
            </a>
        </li>
        <li class="divider">
        </li>
        <li>
            <a href="../index.php">
                <i class="icon icon-road icon-2x">
                </i>
                Tham quang trang web
            </a>
        </li>
        <li class="divider">
        </li>
        <li>
            <a href="../admin/logout.php">
                <i class="icon icon-key icon-2x">
                </i>
                Đăng xuất Admin
            </a>
        </li>
    </ul>
</div>

