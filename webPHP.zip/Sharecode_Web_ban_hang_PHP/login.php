<div id="id01" class="modal container">
    <form class="modal-content animate" action="spLogin.php" method="post">
        <div class="">
            <span onclick="document.getElementById('id01').style.display = 'none'" class="close" title="Đóng"> &times; </span>
        </div>
        <div class="container">
            <br><br>
            <h3><strong>Đăng nhập<strong></h3>
                        <br>
                        <label>Tài khoản: </label>
                        <br>
                        <input type="text" name="username" required>
                        <br>
                        <label> Mật khẩu:  </label>
                        <br>
                        <input type="password" name="password" required>
                        <br><br>
                        <label>
                            <input type="checkbox" checked="checked" name="remember"> Nhớ mật khẩu
                        </label>
                        <br>
                        <span class="psw">Quên <a href="#"> mật khẩu?</a></span>
                        <br>
                        <span>Chưa có tài khoản <a onclick="document.getElementById('id02').style.display = 'block'">Đăng ký</a> ngay.<span>
                                <br><br>
                                <button type="submit" name="login" style="width: auto;" class="btn btn-success">Đăng nhập</button>
                                <br><br>
                                </div>
                                <br><br>                            
                                </form>
                                <br><br>
                                </div>
