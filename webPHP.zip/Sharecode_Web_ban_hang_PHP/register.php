
<div id="id02" class="modal container">
    <form class="modal-content animate" action="/action_page.php">
        <div class="">
            <span onclick="document.getElementById('id02').style.display = 'none'" class="close" title="Đóng">&times;</span>
        </div>
        <div class="container">
            <br><br>
            <h3><strong>Đăng Ký<strong></h3>
                        <br>
                        <label>Tài khoản: </label>
                        <br>
                        <input type="text" name="username" required>
                        <br>
                        <label>Email: </label>
                        <br>
                        <input type="email" name="email" required>
                        <br>
                        <label>Số điện thoại: </label>
                        <br>
                        <input type="tel" name="phone" required>
                        <br>
                        <label>Địa chỉ: </label>
                        <br>
                        <input type="text" name="address" required>
                        <br>
                        <label> Mật khẩu:  </label>
                        <br>
                        <input type="password" name="pass" required>
                        <br>
                        <label>Nhập lại: </label>
                        <br>
                        <input type="password" name="repass" required>
                        <br><br>
                        <button type="submit" style="width: auto;" class="btn btn-success">Đăng nhập</button>
                        <br><br>
                        </div>
                        <br><br>
                        </form>
                        <br><br>
                        </div>